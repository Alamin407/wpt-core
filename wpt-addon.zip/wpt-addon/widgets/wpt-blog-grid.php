<?php
namespace Elementor;

use WP_Query;

class Wpt_Blog_Grid extends Widget_Base {

    public function get_name() {
        return  'wpt-blog-grid';
    }

    public function get_title() {
        return esc_html__( 'Wpt Blog Grid', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'wpt_blog_grid_content',
			[
				'label' => esc_html__( 'Wpt Blog Grid', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
            'wpt_blog_count',
            [
                'label' => __('Number of Posts', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5,
            ]
        );

        $this->add_control(
			'wpt_blog_show_title',
			[
				'label' => esc_html__( 'Show Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'wpt_blog_show_excerpt',
			[
				'label' => esc_html__( 'Show Excerpt', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
            'wpt_blog_excerpt_length',
            [
                'label' => __('Excerpt Length', 'your-text-domain'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 20,
            ]
        );

        $this->add_control(
			'wpt_blog_show_date',
			[
				'label' => esc_html__( 'Show Date', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'wpt_blog_show_button',
			[
				'label' => esc_html__( 'Show Button', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'wpt_blog_button_title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Read More', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your title here', 'textdomain' ),
			]
		);

        $this->add_control(
			'wpt_blog_show_pagi',
			[
				'label' => esc_html__( 'Show Pagination', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        //Animate order content Style Settings
        $this->start_controls_section(
			'wpt_blog_grid_style',
			[
				'label' => esc_html__( 'Wpt Blog Grid', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Wrapper Style
        $this->add_control(
			'wpt_blog_grid_wrapper_style',
			[
				'label' => esc_html__( 'Wrapper Style', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_blog_grid_wrapper_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-blog-grid .wpt-blog-card',
			]
		);

        // Wrapper Border Radius
        $this->add_control(
			'wpt_blog_grid_wrapper_radius',
			[
				'label' => esc_html__( 'Border Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Wrapper Padding
        $this->add_responsive_control(
			'wpt_blog_grid_wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Blog Title Style
        $this->add_control(
			'wpt_blog_grid_title_style',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_blog_grid_title_color',
			[
				'label' => esc_html__( 'Title Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-title h3' => 'color: {{VALUE}}',
				],
			]
		);

        // typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_blog_grid_title_typography',
				'selector' => '{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-title h3',
			]
		);

        // Spacing
        $this->add_responsive_control(
			'wpt_blog_grid_title_spacing',
			[
				'label' => esc_html__( 'Spacing', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Blog Excerpt Style
        $this->add_control(
			'wpt_blog_grid_excerpt_style',
			[
				'label' => esc_html__( 'Excerpt', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_blog_grid_excerpt_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-excerpt p' => 'color: {{VALUE}}',
				],
			]
		);

        // typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_blog_grid_excerpt_typography',
				'selector' => '{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-excerpt p',
			]
		);

        // Spacing
        $this->add_responsive_control(
			'wpt_blog_grid_excerpt_spacing',
			[
				'label' => esc_html__( 'Spacing', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Blog Date Style
        $this->add_control(
			'wpt_blog_grid_date_style',
			[
				'label' => esc_html__( 'Date', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Color
        $this->add_control(
			'wpt_blog_grid_date_color',
			[
				'label' => esc_html__( 'Date Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-date span' => 'color: {{VALUE}}',
				],
			]
		);

        // typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_blog_grid_date_typography',
				'selector' => '{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-date span',
			]
		);

        // Spacing
        $this->add_responsive_control(
			'wpt_blog_grid_date_spacing',
			[
				'label' => esc_html__( 'Spacing', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-blog-date' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Button Style
        $this->add_control(
			'wpt_blog_grid_button_style',
			[
				'label' => esc_html__( 'Button', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_blog_grid_button_typography',
				'selector' => '{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more',
			]
		);

        $this->start_controls_tabs(
			'wpt_blog_grid_button_style_tabs'
		);

        $this->start_controls_tab(
			'wpt_blog_grid_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'textdomain' ),
			]
		);

        //Color
        $this->add_control(
			'wpt_blog_grid_button_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more' => 'color: {{VALUE}}',
				],
			]
		);

        //background
        $this->add_control(
			'wpt_blog_grid_button_normal_text_background',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more' => 'background: {{VALUE}}',
				],
			]
		);

        // Border
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpt_blog_grid_button_normal_border',
				'selector' => '{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
			'wpt_blog_grid_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'textdomain' ),
			]
		);

        //Color
        $this->add_control(
			'wpt_blog_grid_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more:hover' => 'color: {{VALUE}}',
				],
			]
		);

        //background
        $this->add_control(
			'wpt_blog_grid_button_hover_text_background',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more:hover' => 'background: {{VALUE}}',
				],
			]
		);

        //border color
        $this->add_control(
			'wpt_blog_grid_button_hover_text_bdr_color',
			[
				'label' => esc_html__( 'Border Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Border Radius
        $this->add_control(
			'wpt_blog_grid_button_radius',
			[
				'label' => esc_html__( 'Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        //Padding
		$this->add_responsive_control(
			'wpt_blog_grid_button_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-blog-grid .wpt-blog-card .wpt-button .wpt-read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Pagination Style
        $this->add_control(
			'wpt_blog_grid_pagi_style',
			[
				'label' => esc_html__( 'Pagination', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_blog_grid_pagi_typography',
				'selector' => '{{WRAPPER}} .wpt-paginate .page-numbers',
			]
		);

        $this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
			'wpt_blog_grid_pagi_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'textdomain' ),
			]
		);

        //Color
        $this->add_control(
			'wpt_blog_grid_pagi_normal_text_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers' => 'color: {{VALUE}}',
				],
			]
		);

        //background
        $this->add_control(
			'wpt_blog_grid_pagi_normal_background',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers' => 'background: {{VALUE}}',
				],
			]
		);

        // Border
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpt_blog_grid_pagi_normal_border',
				'selector' => '{{WRAPPER}} .wpt-paginate .page-numbers',
			]
		);


        $this->end_controls_tab();

        //Hover
        $this->start_controls_tab(
			'wpt_blog_grid_pagi_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'textdomain' ),
			]
		);

        //Color
        $this->add_control(
			'wpt_blog_grid_pagi_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers:hover' => 'color: {{VALUE}}',
				],
			]
		);

        //background
        $this->add_control(
			'wpt_blog_grid_pagi_hover_background',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers:hover' => 'background: {{VALUE}}',
				],
			]
		);

        //border color
        $this->add_control(
			'wpt_blog_grid_pagi_hover_bdr_color',
			[
				'label' => esc_html__( 'Border Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        //Active
        $this->start_controls_tab(
			'wpt_blog_grid_pagi_active_tab',
			[
				'label' => esc_html__( 'Active', 'textdomain' ),
			]
		);

        //Color
        $this->add_control(
			'wpt_blog_grid_pagi_active_text_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers.current' => 'color: {{VALUE}}',
				],
			]
		);

        //background
        $this->add_control(
			'wpt_blog_grid_pagi_active_background',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers.current' => 'background: {{VALUE}}',
				],
			]
		);

        //background
        $this->add_control(
			'wpt_blog_grid_pagi_active_bdr_color',
			[
				'label' => esc_html__( 'Border Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers.current' => 'border-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

		$this->end_controls_tabs();

        // Border Radius
        $this->add_control(
			'wpt_blog_grid_pagi_radius',
			[
				'label' => esc_html__( 'Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        //Padding
		$this->add_responsive_control(
			'wpt_blog_grid_pagi_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate .page-numbers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        //Spacing
		$this->add_responsive_control(
			'wpt_blog_grid_pagi_spacing',
			[
				'label' => esc_html__( 'Spacing', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-paginate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Post Coust
        $post_per_page = isset( $settings[ 'wpt_blog_count' ] ) ? $settings[ 'wpt_blog_count' ] : 5;

        // Get the current page number from the query string
        $current_page = (get_query_var('paged')) ? get_query_var('paged') : 1;

        // Query the database to fetch a paginated list of blog posts
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $post_per_page,
            'paged' => $current_page,
        );

        $query = new WP_Query($args);

        ?>
         <div class="wpt-blog-grid-wrap">
                <?php
                    if( $query->have_posts() ){
                        ?>
                    <div class="wpt-blog-grid">
                        <?php
                        while( $query->have_posts() ){
                            $query->the_post();
                            ?>
                                <div class="wpt-blog-card">
                                    <div class="wpt-card-header">
                                        <?php 
                                            if( has_post_thumbnail() ){
                                                ?>
                                                    <div class="wpt-thumbnail">
                                                        <?php echo get_the_post_thumbnail(); ?>
                                                    </div>
                                                <?php
                                            }
                                        ?>
                                    </div>
                                    <div class="wpt-card-body">
                                        <?php 
                                            if( $settings[ 'wpt_blog_show_title' ] == 'yes' ){
                                                ?>
                                                    <div class="wpt-blog-title">
                                                        <h3><?php echo get_the_title(); ?></h3>
                                                    </div>
                                                <?php
                                            }
                                        ?>
                                        <?php
                                            if( $settings[ 'wpt_blog_show_date' ] == 'yes' ){
                                                ?>
                                                    <div class="wpt-blog-date">
                                                        <span><?php echo get_the_date(); ?></span>
                                                    </div>
                                                <?php
                                            }
                                        ?>
                                        <?php 
                                            if( $settings[ 'wpt_blog_show_excerpt' ] == 'yes' ){
                                                ?>
                                                    <div class="wpt-blog-excerpt">
                                                        <p>
                                                            <?php 
                                                                $excerpt_length = isset( $settings[ 'wpt_blog_excerpt_length' ] ) ? $settings[ 'wpt_blog_excerpt_length' ] : 20;
                                                                echo wp_trim_words( get_the_excerpt(), $excerpt_length ); 
                                                            ?>
                                                        </p>
                                                    </div>
                                                <?php
                                            } 
                                        ?>
                                        <?php
                                            if( $settings[ 'wpt_blog_show_button' ] == 'yes' ){
                                                ?>
                                                    <div class="wpt-button">
                                                        <a href="<?php echo get_permalink(); ?>" class="wpt-read-more"><?php echo $settings[ 'wpt_blog_button_title' ]; ?></a>
                                                    </div>
                                                <?php
                                            }
                                        ?>
                                    </div>
                                </div>
                            <?php
                        }
                        ?>
                    </div>
                        <?php
                        if( $settings[ 'wpt_blog_show_pagi' ] == 'yes' ){
                            ?>
                                <div class="wpt-paginate">
                                    <?php
                                        echo paginate_links(array(
                                            'total' => $query->max_num_pages,
                                            'current' => $current_page
                                        ));
                                    ?>
                                </div>
                            <?php
                        }
                        wp_reset_postdata();
                    }
                ?>
         </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpt_Blog_Grid() );