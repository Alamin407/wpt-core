<?php
namespace Elementor;

class Wpt_Icon_Box extends Widget_Base {

    public function get_name() {
        return  'wpt-icon-box';
    }

    public function get_title() {
        return esc_html__( 'Wpt Icon Box', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-icon-box';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'wpt_icon_box_content_section',
			[
				'label' => esc_html__( 'Wpt Icon Box', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Icon
        $this->add_control(
			'wpt_icon_box_image',
			[
				'label' => esc_html__( 'Choose Image', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        // Heading
        $this->add_control(
			'wpt_icon_box_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your title here', 'wpt-addon' ),
                'label_block' => true,
			]
		);

        // Description
        $this->add_control(
			'wpt_icon_box_description',
			[
				'label' => esc_html__( 'Description', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => esc_html__( 'Default description', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Type your description here', 'wpt-addon' ),
			]
		);

        $this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        //Animate order content Style Settings
        $this->start_controls_section(
			'wpt_icon_box_content_section_style',
			[
				'label' => esc_html__( 'Wpt Icon Box', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        // Wrapper
        $this->add_control(
			'wpt_icon_box_wrapper',
			[
				'label' => esc_html__( 'Box Wrapper', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Wrapper background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_icon_box_wrapper_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-card',
			]
		);

        // Wrapper Border
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpt_icon_box_wrapper_border',
				'selector' => '{{WRAPPER}} .wpt-card',
			]
		);
        // Wrapper Border Border radius
        $this->add_responsive_control(
			'wpt_icon_box_wrapper_radius',
			[
				'label' => esc_html__( 'Border Radious', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        // Wrapper Padding
        $this->add_responsive_control(
			'wpt_icon_box_wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        // Icon Style
        // Icon
        $this->add_control(
			'wpt_icon_box_icon_style',
			[
				'label' => esc_html__( 'Icon', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        // Icon background
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_icon_box_icon_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon',
			]
		);

        // Icon Width
        $this->add_responsive_control(
			'wpt_icon_box_icon_width',
			[
				'label' => esc_html__( 'Width', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 103,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Height
        $this->add_responsive_control(
			'wpt_icon_box_icon_height',
			[
				'label' => esc_html__( 'Height', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 103,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        // Icon Top Position
        $this->add_responsive_control(
			'wpt_icon_box_icon_pos_top',
			[
				'label' => esc_html__( 'Top Position', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Left Position
        $this->add_responsive_control(
			'wpt_icon_box_icon_pos_left',
			[
				'label' => esc_html__( 'Left Position', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 25,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Border radius
        $this->add_responsive_control(
			'wpt_icon_box_icon_radius',
			[
				'label' => esc_html__( 'Border Radious', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        // Icon Box Shadow
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'wpt_icon_box_icon_box_shadow',
				'selector' => '{{WRAPPER}} .wpt-card .wpt-card-header .wpt-icon',
			]
		);

        // Content Style
        // Title
        $this->add_control(
			'wpt_icon_box_title_style',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        // Margin
        $this->add_responsive_control(
			'wpt_icon_box_title_margin',
			[
				'label' => esc_html__( 'Margin Top', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-body h3' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Title Color
        $this->add_control(
			'wpt_icon_box_title_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-body h3' => 'color: {{VALUE}}',
				],
			]
		);
        // Title Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_icon_box_title_typography',
				'selector' => '{{WRAPPER}} .wpt-card .wpt-card-body h3',
			]
		);
        // Description
        $this->add_control(
			'wpt_icon_box_desc_style',
			[
				'label' => esc_html__( 'Description', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        // Margin
        $this->add_responsive_control(
			'wpt_icon_box_desc_margin',
			[
				'label' => esc_html__( 'Margin Top', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-body p' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Title Color
        $this->add_control(
			'wpt_icon_box_desc_color',
			[
				'label' => esc_html__( 'Title Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-card .wpt-card-body p' => 'color: {{VALUE}}',
				],
			]
		);
        // Title Typhography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_icon_box_desc_typography',
				'selector' => '{{WRAPPER}} .wpt-card .wpt-card-body p',
			]
		);
		
		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
         <div class="wpt-card">
            <div class="wpt-card-header">
                <div class="wpt-icon">
                    <img src="<?php echo $settings[ 'wpt_icon_box_image' ][ 'url' ]; ?>" alt="icon" class="icon">
                </div>
            </div>
            <div class="wpt-card-body">
                <h3><?php echo $settings[ 'wpt_icon_box_title' ]; ?></h3>
                <p><?php echo $settings[ 'wpt_icon_box_description' ]; ?></p>
            </div>
         </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpt_Icon_Box() );