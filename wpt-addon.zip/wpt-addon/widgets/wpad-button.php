<?php
namespace Elementor;

class Wpad_Button extends Widget_Base {

    public function get_name() {
        return  'wpad-button';
    }

    public function get_title() {
        return esc_html__( 'Animated Button', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return ' eicon-button';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'wpad_button_content_section',
			[
				'label' => esc_html__( 'Button', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

        // Title Control
        $this->add_control(
			'wpad_button_title',
			[
				'label' => esc_html__( 'Title', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Click Here', 'wpt-addon' ),
				'placeholder' => esc_html__( 'Click Here', 'wpt-addon' ),
			]
		);
		// Button url
		$this->add_control(
			'wpad_button_link',
			[
				'label' => esc_html__( 'Link', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'wpt-addon' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
        // Button Icons Control
        $this->add_control(
			'wpad_button_icon',
			[
				'label' => esc_html__( 'Icon Class', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'fa-solid fa-arrow-right', 'wpt-addon' ),
				'placeholder' => esc_html__( 'fa-solid fa-arrow-right', 'wpt-addon' ),
                'label_block' => true,
                'description' => esc_html__( 'Enter your fontawesome icon class default is fa-solid fa-arrow-right' ),
			]
		);

        $this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        //Animate order content Style Settings
        $this->start_controls_section(
			'wpad_button_content_section_style',
			[
				'label' => esc_html__( 'Button', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		// Animate Button Background Color
        $this->add_control(
			'wpad_button_color_body_background',
			[
				'label' => esc_html__( 'Button Body Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn' => 'background: {{VALUE}}',
				],
				'default' => '#F26C4F'
			]
		);
		// Wpad Style Tab
		$this->start_controls_tabs(
			'wpad_style_tabs'
		);
		// Normal Tab
		$this->start_controls_tab(
			'wpad_button_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'wpt-addon' ),
			]
		);
		// Animate Button Text Color
        $this->add_control(
			'wpad_button_text_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn .wpad-vissible' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        // Animate Button Background Color
        $this->add_control(
			'wpad_button_color_normal_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn .wpad-vissible' => 'background: {{VALUE}}',
				],
				'default' => '#F26C4F'
			]
		);
		//Animate Button Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpad_button_normal_border',
				'label' => esc_html__( 'Border', 'wpt-addon' ),
				'selector' => '{{WRAPPER}} .wpad-button .wpad-anim-btn .wpad-vissible',
			]
		);
		$this->end_controls_tab();
		//Hover Tab
        $this->start_controls_tab(
			'wpad_button_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'wpt-addon' ),
			]
		);
		// Animate Button Text Color
        $this->add_control(
			'wpad_button_hover_text_color',
			[
				'label' => esc_html__( 'Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn .wpad-hidden' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        // Animate Border Background Color
        $this->add_control(
			'wpad_button_color_hover_background',
			[
				'label' => esc_html__( 'Background', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn .wpad-hidden' => 'background: {{VALUE}}',
				],
				'default' => 'rgb(212, 71, 41)'
			]
		);
		//Animate Button Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpad_button_hover_border',
				'label' => esc_html__( 'Border', 'wpt-addon' ),
				'selector' => '{{WRAPPER}} .wpad-button .wpad-anim-btn .wpad-hidden',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
        //Button Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpad_button_typography',
				'selector' => '{{WRAPPER}} .wpad-button .wpad-anim-btn span',
			]
		);
        // Animate Button arrow Color
        $this->add_control(
			'wpad_button_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn span i' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        // Icon Size
        $this->add_control(
			'wpad_button_icon_font_size',
			[
				'label' => esc_html__( 'Size', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn span i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        // Icon Size
        $this->add_control(
			'wpad_button_icon_space',
			[
				'label' => esc_html__( 'Icon Specing', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn span i' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
        //Button Padding
		$this->add_control(
			'wpad_button_padding',
			[
				'label' => esc_html__( 'Padding', 'wpt-addon' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .wpad-button .wpad-anim-btn span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'unit' => 'px',
					'top' => 13,
					'right' => 20,
					'bottom' => 13,
					'left' => 20,
				],
			]
		);
		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		if( ! empty( $settings[ 'wpad_button_link' ][ 'url' ] ) ){
			$this->add_link_attributes( 'wpad_button_link', $settings[ 'wpad_button_link' ] );
		}
		$btnlinktarget = $settings[ 'wpad_button_link' ][ 'is_external' ] ? ' target="_blank"' : '';
        $btnlinknofollow = $settings[ 'wpad_button_link' ][ 'nofollow' ] ? ' rel="nofollow"' : '';
        ?>
         <div class="wpad-button">
            <a <?php echo $this->get_render_attribute_string( 'wpad_button_link' ); ?> class="wpad-anim-btn" <?php echo $btnlinktarget; ?> <?php echo $btnlinknofollow; ?> >
                <span class="wpad-vissible">
                    <?php echo $settings[ 'wpad_button_title' ]; ?>
                    <i class="<?php echo $settings[ 'wpad_button_icon' ]; ?>"></i>
                </span>
                <span class="wpad-hidden">
                    <?php echo $settings[ 'wpad_button_title' ]; ?>
                    <i class="<?php echo $settings[ 'wpad_button_icon' ]; ?>"></i>
                </span>
            </a>
         </div>
        <?php
    }

    protected function _content_template() {
		?>
		<# 
		var btnlinktarget = settings.wpad_button_link.is_external ? ' target="_blank"' : '';
        var btnlinknofollow = settings.wpad_button_link.nofollow ? ' rel="nofollow"' : '';
		#>
        <div class="wpad-button">
            <a href="{{ settings.wpad_button_link.url }}" class="wpad-anim-btn" btnlinktarget btnlinknofollow >
                <span class="wpad-vissible">
                    {{{ settings.wpad_button_title }}}
                    <i class="{{{ settings.wpad_button_icon }}}"></i>
                </span>
                <span class="wpad-hidden">
                    {{{ settings.wpad_button_title }}}
                    <i class="{{{ settings.wpad_button_icon }}}"></i>
                </span>
            </a>
         </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpad_Button() );