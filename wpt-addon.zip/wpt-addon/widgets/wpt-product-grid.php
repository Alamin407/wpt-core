<?php
namespace Elementor;

class Wpt_Product_Grid extends Widget_Base {

    public function get_name() {
        return  'wpt-product-grid';
    }

    public function get_title() {
        return esc_html__( 'Wpt Product Grid', 'wpt-addon' );
    }

    public function get_script_depends() {
        return [
            'wpt-main-js'
        ];
    }

    public function get_icon() {
        return 'eicon-products';
    }

    public function get_categories() {
        return [ 'wpt-for-elementor' ];
    }

    public function _register_controls() {
        $this->start_controls_section(
			'wpt_product_grid_section',
			[
				'label' => esc_html__( 'Product Grid', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'wpt_grid_image',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'wpt_grid_title',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your title here', 'textdomain' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'wpt_grid_price',
			[
				'label' => esc_html__( 'Price', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your title here', 'textdomain' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'wpt_grid_cart_icon',
			[
				'label' => esc_html__( 'Choose Icon Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'wpt_grid_cart_link',
			[
				'label' => esc_html__( 'Cart Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'wpt_grid_coa_title',
			[
				'label' => esc_html__( 'Coa Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your title here', 'textdomain' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'wpt_grid_coa_link',
			[
				'label' => esc_html__( 'Coa Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'wpt_grid_endotoxin_title',
			[
				'label' => esc_html__( 'Endotoxin Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Default title', 'textdomain' ),
				'placeholder' => esc_html__( 'Type your title here', 'textdomain' ),
				'label_block' => true,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'wpt_grid_endotoxin_link',
			[
				'label' => esc_html__( 'Endotoxin Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'wpt_grid_list',
			[
				'label' => esc_html__( 'Grid Items', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'wpt_grid_title' => esc_html__( 'Title #1', 'textdomain' ),
					],
					[
						'wpt_grid_title' => esc_html__( 'Title #2', 'textdomain' ),
					],
				],
				'title_field' => '{{{ wpt_grid_title }}}',
			]
		);

        $this->end_controls_section();
		// Slider Settings
        $this->start_controls_section(
			'wpt_grid_slider_settings',
			[
				'label' => esc_html__( 'Settings', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );

		// Slider Controller
		// show Loop
        $this->add_control(
            'loop',
            [
                'label' => __( 'Loop', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );

        // show Dots
        $this->add_control(
            'dots',
            [
                'label' => __( 'Dots', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => false,
            ]
        );

        // Show Navs
        $this->add_control(
            'navs',
            [
                'label' => __( 'Navs', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );
        // Show Autoplay
        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Autoplay', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );
        // Autoplay Hover Pause
        $this->add_control(
            'pause',
            [
                'label' => __( 'Pause On Hover', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => true,
                'default' => true,
            ]
        );

        // Margin
        $this->add_control(
            'margin',
            [
                'label' => __( 'Margin', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 10,
                'placeholder' => __( 'Enter the margin between to slides', 'plugin-domain' ),
            ]
        );
        // Autoplay Speed
        $this->add_control(
            'speed',
            [
                'label' => __( 'Autoplay Speed', 'plugin-domain' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 800,
                'placeholder' => __( 'Enter the Autoplay Speed', 'plugin-domain' ),
            ]
        );

		$this->end_controls_section();
        $this->style_tab();
    }

    private function style_tab() {
        $this->start_controls_section(
			'wpt_product_grid_style',
			[
				'label' => esc_html__( 'Wpt Icon Box', 'wpt-addon' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'wpt_product_grid_wrapper_style',
			[
				'label' => esc_html__( 'Wrapper', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		//Wrapper Backgrpund
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_product_grid_wrapper_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item',
			]
		);

		// Wrapper Border Radious
		$this->add_control(
			'wpt_product_grid_wrapper_radius',
			[
				'label' => esc_html__( 'Border Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Wrapper Padding
		$this->add_responsive_control(
			'wpt_product_grid_wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'wpt_product_grid_title_style',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Title Color
		$this->add_control(
			'wpt_product_grid_title_color',
			[
				'label' => esc_html__( 'Title Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body h3' => 'color: {{VALUE}}',
				],
			]
		);

		// Title Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_product_grid_title_typography',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body h3',
			]
		);

		// Title Margin Top
		$this->add_responsive_control(
			'wpt_product_grid_title_margin',
			[
				'label' => esc_html__( 'Margin Top', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body h3.title' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'wpt_product_grid_price_style',
			[
				'label' => esc_html__( 'Price', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Title Color
		$this->add_control(
			'wpt_product_grid_price_color',
			[
				'label' => esc_html__( 'Title Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box h3' => 'color: {{VALUE}}',
				],
			]
		);

		// Price Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_product_grid_price_typography',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box h3',
			]
		);

		// Price Margin Top
		$this->add_responsive_control(
			'wpt_product_grid_price_margin',
			[
				'label' => esc_html__( 'Margin Top', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// Cart Style
		$this->add_control(
			'wpt_product_grid_cart_style',
			[
				'label' => esc_html__( 'Cart', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Cart Background Color
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'wpt_product_grid_cart_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box .wpt-cart',
			]
		);

		// Cart Typhography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_product_grid_cart_typography',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box .wpt-cart',
			]
		);

		// Cart Width
		$this->add_responsive_control(
			'wpt_product_grid_cart_width',
			[
				'label' => esc_html__( 'Width', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box .wpt-cart' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Cart Height
		$this->add_responsive_control(
			'wpt_product_grid_cart_height',
			[
				'label' => esc_html__( 'Height', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box .wpt-cart' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Cart Border Radious
		$this->add_control(
			'wpt_product_grid_cart_radius',
			[
				'label' => esc_html__( 'Border Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box .wpt-cart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Cart Icon Size
		// Cart Height
		$this->add_responsive_control(
			'wpt_product_grid_cart_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-body .price-box .wpt-cart img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Coa Button Style
		$this->add_control(
			'wpt_product_grid_coa_style',
			[
				'label' => esc_html__( 'Coa Button', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'wpt_product_grid_coa_style_tabs'
		);

		$this->start_controls_tab(
			'wpt_product_grid_coa_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'textdomain' ),
			]
		);

		//  Text Color
		$this->add_control(
			'wpt_product_grid_coa_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa' => 'color: {{VALUE}}',
				],
			]
		);

		// Background Color
		$this->add_control(
			'wpt_product_grid_coa_normal_background',
			[
				'label' => esc_html__( 'Background Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa' => 'background: {{VALUE}}',
				],
			]
		);

		//Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpt_product_grid_coa_normal_border',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'wpt_product_grid_coa_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'textdomain' ),
			]
		);

		//  Text Color
		$this->add_control(
			'wpt_product_grid_coa_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa:hover' => 'color: {{VALUE}}',
				],
			]
		);

		// Background Color
		$this->add_control(
			'wpt_product_grid_coa_hover_background',
			[
				'label' => esc_html__( 'Background Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa:hover' => 'background: {{VALUE}}',
				],
			]
		);

		//Hover Border Color
		$this->add_control(
			'wpt_product_grid_coa_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		// Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_product_grid_coa_typography',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa',
			]
		);

		// Border Radous
		$this->add_control(
			'wpt_product_grid_coa_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		// Border Radous
		$this->add_responsive_control(
			'wpt_product_grid_coa_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-coa' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Endotoxin Button Style
		$this->add_control(
			'wpt_product_grid_endotoxin_style',
			[
				'label' => esc_html__( 'Endotoxin Button', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
			'wpt_product_grid_endotoxin_style_tabs'
		);

		$this->start_controls_tab(
			'wpt_product_grid_endotoxin_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'textdomain' ),
			]
		);

		//  Text Color
		$this->add_control(
			'wpt_product_grid_endotoxin_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo' => 'color: {{VALUE}}',
				],
			]
		);

		// Background Color
		$this->add_control(
			'wpt_product_grid_endotoxin_normal_background',
			[
				'label' => esc_html__( 'Background Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo' => 'background: {{VALUE}}',
				],
			]
		);

		//Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'wpt_product_grid_endotoxin_normal_border',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'wpt_product_grid_endotoxin_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'textdomain' ),
			]
		);

		//  Text Color
		$this->add_control(
			'wpt_product_grid_endotoxin_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo:hover' => 'color: {{VALUE}}',
				],
			]
		);

		// Background Color
		$this->add_control(
			'wpt_product_grid_endotoxin_hover_background',
			[
				'label' => esc_html__( 'Background Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo:hover' => 'background: {{VALUE}}',
				],
			]
		);

		//Hover Border Color
		$this->add_control(
			'wpt_product_grid_endotoxin_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		// Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'wpt_product_grid_endotoxin_typography',
				'selector' => '{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo',
			]
		);

		// Border Radous
		$this->add_control(
			'wpt_product_grid_endotoxin_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		// Padding
		$this->add_responsive_control(
			'wpt_product_grid_endotoxin_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .wpt-grid-wrap .wpt-grid-content .wpt-grid-slider .item .wpt-grid-slider-item .wpt-grid-footer .button-box .wpt-endo' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		$this->add_render_attribute(
            'wpt_product_grid_carousel_options',
            [
                'id'          => 'wpt-product-grid-' . $this->get_id(),
                'data-loop'   => $settings[ 'loop' ],
                'data-dots'   => $settings[ 'dots' ],
                'data-navs'   => $settings[ 'navs' ],
                'data-margin' => $settings[ 'margin' ],
                'data-autoplay' => $settings[ 'autoplay' ],
                'data-pause' => $settings[ 'pause' ],
                'data-speed' => $settings[ 'speed' ],
            ]
        );
        ?>
         <div class="wpt-grid-wrap">
			<div class="wpt-grid-content">
				<div class="owl-carousel owl-theme wpt-grid-slider" <?php echo $this->get_render_attribute_string('wpt_product_grid_carousel_options'); ?>>
					<?php
						foreach( $settings[ 'wpt_grid_list' ] as $item ){
							?>
								<div class="item">
									<div class="wpt-grid-slider-item">
										<div class="wpt-grid-header">
											<img src="<?php echo $item[ 'wpt_grid_image' ][ 'url' ]; ?>" alt="">
										</div>
										<div class="wpt-grid-body">
											<h3 class="title"><?php echo $item[ 'wpt_grid_title' ] ?></h3>
											<div class="price-box">
												<div class="price">
													<h3><?php echo $item[ 'wpt_grid_price' ] ?></h3>
												</div>
												<div class="wpt-cart-btn">
													<a href="<?php echo $item[ 'wpt_grid_cart_link' ][ 'url' ]; ?>" class="wpt-cart">
														<img src="<?php echo $item[ 'wpt_grid_cart_icon' ][ 'url' ]; ?>" alt="">
													</a>
												</div>
											</div>
										</div>
										<div class="wpt-grid-footer">
											<div class="button-box">
												<div class="coa">
													<a href="<?php echo $item[ 'wpt_grid_coa_link' ][ 'url' ]; ?>" class="wpt-coa"><?php echo $item[ 'wpt_grid_coa_title' ]; ?></a>
												</div>
												<div class="endotoxin">
													<a href="<?php echo $item[ 'wpt_grid_endotoxin_link' ][ 'url' ]; ?>" class="wpt-endo"><?php echo $item[ 'wpt_grid_endotoxin_title' ]; ?></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php
						}
					?>
				</div>
			</div>
		 </div>
        <?php
    }

}
Plugin::instance()->widgets_manager->register_widget_type( new Wpt_Product_Grid() );